import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './main.css';
import SearchBar from '../components/SearchBar'; 
import ViewedRecipes from '../components/ViewedRecipes';  

const fetchBestRecipe = async () => {
  // 백엔드에서 베스트 레시피 데이터 받아오기
  try {
    const response = await axios.get('/api/recipes/best');
    return response.data;
  } catch (error) {
    console.error('Error fetching best recipe:', error);
    return null;
  }
};

const fetchRandomRecipe = async () => {
  // 백엔드에서 랜덤 레시피 데이터 받아오기
  try {
    const response = await axios.get('/api/recipes/random');
    return response.data;
  } catch (error) {
    console.error('Error fetching random recipe:', error);
    return null;
  }
};

const fetchOtherRecipes = async () => {
  // 백엔드에서 기타 레시피 데이터 받아오기
  try {
    const response = await axios.get('/api/recipes/all');
    return response.data;
  } catch (error) {
    console.error('Error fetching other recipes:', error);
    return [];
  }
};

function Main() {
  const [bestRecipe, setBestRecipe] = useState(null);
  const [randomRecipe, setRandomRecipe] = useState(null);
  const [otherRecipes, setOtherRecipes] = useState([]);
  const [searchResults, setSearchResults] = useState([]);

  // 데이터 로딩용
  useEffect(() => {
    const getRecipes = async () => {
      const best = await fetchBestRecipe();
      const random = await fetchRandomRecipe();
      const others = await fetchOtherRecipes();

      setBestRecipe(best);
      setRandomRecipe(random);
      setOtherRecipes(others);
    };

    getRecipes();
  }, []);

  return (
    <div className="main-container">
      <header className="main-header">
        <SearchBar setSearchResults={setSearchResults} /> {/* SearchBar 컴포넌트 사용 */}
      </header>

      <section className="main-content">
        <div className="container">
          <div className="main-layout">
            {/* 왼쪽 메인 레시피 콘텐츠 */}
            <div className="main-recipes">
              <h2>오늘의 추천</h2>
              <div className="recipe-section">
                {/* 베스트 레시피 */}
                {bestRecipe && (
                  <div className="best-recipe">
                    <h3>베스트 레시피</h3>
                    <img src={bestRecipe.imageUrl} alt="대표 이미지" className="recipe-image" />
                    <p className="recipe-name">{bestRecipe.recipeName}</p>
                  </div>
                )}

                {/* 랜덤 레시피 */}
                {randomRecipe && (
                  <div className="random-recipe">
                    <h3>오늘의 추천 레시피</h3>
                    <img src={randomRecipe.imageUrl} alt="대표 이미지" className="recipe-image" />
                    <p className="recipe-name">{randomRecipe.recipeName}</p>
                  </div>
                )}

                {/* 검색 결과 */}
                {searchResults.length > 0 && (
                  <div className="search-results">
                    <h3>검색 결과</h3>
                    {searchResults.map((recipe, index) => (
                      <div key={index} className="recipe-card">
                        <img src={recipe.imageUrl} alt="레시피 이미지" />
                        <p>{recipe.recipeName}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 기타 인기 레시피 */}
              <div className="additional-recipes">
                <h3>기타 인기 레시피</h3>
                <div className="recipe-grid">
                  {otherRecipes.map((recipe, index) => (
                    <div key={index} className="recipe-card">
                      <img src={recipe.imageUrl} alt="레시피 이미지" />
                      <p>{recipe.recipeName}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* 오른쪽 사이드 오늘의 열람 레시피 */}
            <ViewedRecipes />
          </div>
        </div>
      </section>

    </div>
  );
}

export default Main;
